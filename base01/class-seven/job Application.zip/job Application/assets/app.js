 const fullname= document.getElementById('fullname');
 fullname.style.background = "red";
 fullname.style.color = " blue"

 